// src/screens/GameScreen.js
// ============================================================
// Main game screen: wires together board, controls, HUD
// ============================================================

import React, { useCallback, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  StatusBar,
  PanResponder,
} from 'react-native';

import GameBoard       from '../components/GameBoard';
import DirectionPad    from '../components/DirectionPad';
import ScoreBoard      from '../components/ScoreBoard';
import GameOverOverlay from '../components/GameOverOverlay';
import useGameLoop     from '../hooks/useGameLoop';
import useHighScore    from '../hooks/useHighScore';
import useSound        from '../hooks/useSound';
import { COLORS, GAME_STATE, DIRECTION } from '../utils/constants';

const MIN_SWIPE = 30; // Minimum px to count as a swipe

const GameScreen = () => {
  const { highScore, updateHighScore } = useHighScore();
  const { playEat, playDie }           = useSound();

  const {
    gameState, snake, food, score, speed,
    changeDirection, startGame, pauseGame, resumeGame, restartGame,
  } = useGameLoop({
    onEat: playEat,
    onDie: playDie,
    updateHighScore,
  });

  const isRunning  = gameState === GAME_STATE.RUNNING;
  const isPaused   = gameState === GAME_STATE.PAUSED;
  const isGameOver = gameState === GAME_STATE.GAME_OVER;
  const isNewHigh  = score > 0 && score >= highScore;

  // ── Swipe gesture support ──────────────────────────────────
  const swipeStart = useRef({ x: 0, y: 0 });

  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onPanResponderGrant: (e) => {
        swipeStart.current = { x: e.nativeEvent.pageX, y: e.nativeEvent.pageY };
      },
      onPanResponderRelease: (e) => {
        const dx = e.nativeEvent.pageX - swipeStart.current.x;
        const dy = e.nativeEvent.pageY - swipeStart.current.y;
        if (Math.abs(dx) < MIN_SWIPE && Math.abs(dy) < MIN_SWIPE) return;

        if (Math.abs(dx) > Math.abs(dy)) {
          changeDirection(dx > 0 ? DIRECTION.RIGHT : DIRECTION.LEFT);
        } else {
          changeDirection(dy > 0 ? DIRECTION.DOWN : DIRECTION.UP);
        }
      },
    }),
  ).current;

  // ── Pause / Resume toggle ──────────────────────────────────
  const handlePauseResume = useCallback(() => {
    if (isRunning) pauseGame();
    else if (isPaused) resumeGame();
  }, [isRunning, isPaused, pauseGame, resumeGame]);

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor={COLORS.BG} />

      <View style={styles.container}>
        {/* ── Header ── */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>🐍 SNAKE NEON</Text>

          {isRunning || isPaused ? (
            <TouchableOpacity style={styles.pauseBtn} onPress={handlePauseResume}>
              <Text style={styles.pauseBtnText}>{isRunning ? '⏸' : '▶'}</Text>
            </TouchableOpacity>
          ) : null}
        </View>

        {/* ── Score HUD ── */}
        <ScoreBoard score={score} highScore={highScore} speed={speed} />

        {/* ── Board + overlay ── */}
        <View style={styles.boardWrapper} {...panResponder.panHandlers}>
          <GameBoard snake={snake} food={food} />

          {/* Paused overlay */}
          {isPaused && (
            <View style={styles.pauseOverlay}>
              <Text style={styles.pauseTitle}>PAUSED</Text>
              <TouchableOpacity style={styles.resumeBtn} onPress={resumeGame}>
                <Text style={styles.resumeBtnText}>▶  RESUME</Text>
              </TouchableOpacity>
            </View>
          )}

          {/* Game Over overlay */}
          {isGameOver && (
            <GameOverOverlay
              score={score}
              highScore={highScore}
              onRestart={restartGame}
              isNewHigh={isNewHigh}
            />
          )}

          {/* Idle (not started) overlay */}
          {gameState === GAME_STATE.IDLE && (
            <View style={styles.pauseOverlay}>
              <TouchableOpacity style={styles.startBtn} onPress={startGame}>
                <Text style={styles.startBtnText}>▶  START</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>

        {/* ── Direction pad ── */}
        <DirectionPad onDirectionChange={changeDirection} />

        {/* ── Restart hint ── */}
        {(isRunning || isPaused) && (
          <TouchableOpacity style={styles.restartSmall} onPress={restartGame}>
            <Text style={styles.restartSmallText}>↺ Restart</Text>
          </TouchableOpacity>
        )}
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: COLORS.BG,
  },
  container: {
    flex: 1,
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingTop: 8,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
    marginBottom: 8,
    paddingHorizontal: 4,
  },
  headerTitle: {
    color: COLORS.TEXT_ACCENT,
    fontSize: 16,
    fontWeight: '900',
    letterSpacing: 3,
    fontFamily: 'monospace',
  },
  pauseBtn: {
    backgroundColor: COLORS.BTN_PRIMARY,
    borderWidth: 1,
    borderColor: COLORS.BTN_BORDER,
    borderRadius: 10,
    paddingVertical: 4,
    paddingHorizontal: 14,
  },
  pauseBtnText: {
    color: COLORS.TEXT_PRIMARY,
    fontSize: 18,
  },
  boardWrapper: {
    position: 'relative',
  },
  pauseOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: COLORS.OVERLAY_BG,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 5,
    borderRadius: 4,
  },
  pauseTitle: {
    color: COLORS.TEXT_PRIMARY,
    fontSize: 32,
    fontWeight: '900',
    letterSpacing: 8,
    fontFamily: 'monospace',
    marginBottom: 24,
  },
  resumeBtn: {
    backgroundColor: COLORS.SNAKE_HEAD,
    paddingVertical: 12,
    paddingHorizontal: 32,
    borderRadius: 50,
    shadowColor: COLORS.SNAKE_HEAD,
    shadowOpacity: 0.6,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 0 },
    elevation: 8,
  },
  resumeBtnText: {
    color: COLORS.BG,
    fontSize: 16,
    fontWeight: '900',
    letterSpacing: 3,
    fontFamily: 'monospace',
  },
  startBtn: {
    backgroundColor: COLORS.SNAKE_HEAD,
    paddingVertical: 14,
    paddingHorizontal: 40,
    borderRadius: 50,
    shadowColor: COLORS.SNAKE_HEAD,
    shadowOpacity: 0.7,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 0 },
    elevation: 10,
  },
  startBtnText: {
    color: COLORS.BG,
    fontSize: 18,
    fontWeight: '900',
    letterSpacing: 3,
    fontFamily: 'monospace',
  },
  restartSmall: {
    marginTop: 8,
    paddingVertical: 6,
    paddingHorizontal: 20,
  },
  restartSmallText: {
    color: COLORS.TEXT_DIM,
    fontSize: 13,
    fontWeight: '600',
    letterSpacing: 2,
    fontFamily: 'monospace',
  },
});

export default GameScreen;
