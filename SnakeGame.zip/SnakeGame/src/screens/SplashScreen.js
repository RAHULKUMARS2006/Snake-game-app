// src/screens/SplashScreen.js
// ============================================================
// Animated splash/title screen shown when the app first loads
// ============================================================

import React, { useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Animated,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import { COLORS } from '../utils/constants';

const { width } = Dimensions.get('window');

const SplashScreen = ({ onStart }) => {
  // Animation values
  const titleOpacity   = useRef(new Animated.Value(0)).current;
  const titleScale     = useRef(new Animated.Value(0.7)).current;
  const subtitleOpacity = useRef(new Animated.Value(0)).current;
  const btnOpacity     = useRef(new Animated.Value(0)).current;
  const snakePulse     = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    // Entrance sequence
    Animated.sequence([
      Animated.parallel([
        Animated.timing(titleOpacity, { toValue: 1, duration: 700, useNativeDriver: true }),
        Animated.spring(titleScale,   { toValue: 1, friction: 5, useNativeDriver: true }),
      ]),
      Animated.timing(subtitleOpacity, { toValue: 1, duration: 400, useNativeDriver: true }),
      Animated.timing(btnOpacity,      { toValue: 1, duration: 400, useNativeDriver: true }),
    ]).start();

    // Infinite glow pulse on the snake icon
    Animated.loop(
      Animated.sequence([
        Animated.timing(snakePulse, { toValue: 1.12, duration: 900, useNativeDriver: true }),
        Animated.timing(snakePulse, { toValue: 1,    duration: 900, useNativeDriver: true }),
      ]),
    ).start();
  }, [titleOpacity, titleScale, subtitleOpacity, btnOpacity, snakePulse]);

  return (
    <View style={styles.container}>
      {/* Background accent lines */}
      <View style={styles.bgLine1} />
      <View style={styles.bgLine2} />

      {/* Snake icon (emoji + animated scale) */}
      <Animated.Text style={[styles.snakeEmoji, { transform: [{ scale: snakePulse }] }]}>
        🐍
      </Animated.Text>

      {/* Title */}
      <Animated.View style={{ opacity: titleOpacity, transform: [{ scale: titleScale }] }}>
        <Text style={styles.title}>SNAKE</Text>
        <Text style={styles.titleSub}>NEON</Text>
      </Animated.View>

      {/* Tagline */}
      <Animated.Text style={[styles.tagline, { opacity: subtitleOpacity }]}>
        Eat. Grow. Survive.
      </Animated.Text>

      {/* Decorative snake */}
      <Animated.View style={[styles.snakeDecor, { opacity: subtitleOpacity }]}>
        {[...Array(8)].map((_, i) => (
          <View
            key={i}
            style={[
              styles.snakeDot,
              { opacity: 1 - i * 0.1, backgroundColor: i === 0 ? COLORS.SNAKE_HEAD : COLORS.SNAKE_BODY },
            ]}
          />
        ))}
        <View style={[styles.snakeDot, { backgroundColor: COLORS.FOOD, borderRadius: 10 }]} />
      </Animated.View>

      {/* Start button */}
      <Animated.View style={{ opacity: btnOpacity, width: '100%', alignItems: 'center' }}>
        <TouchableOpacity style={styles.startBtn} onPress={onStart} activeOpacity={0.75}>
          <Text style={styles.startBtnText}>▶  START GAME</Text>
        </TouchableOpacity>
      </Animated.View>

      {/* Footer */}
      <Animated.Text style={[styles.footer, { opacity: subtitleOpacity }]}>
        Swipe or tap arrows to move
      </Animated.Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.BG,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 30,
  },
  bgLine1: {
    position: 'absolute',
    top: '15%',
    left: -20,
    right: -20,
    height: 1,
    backgroundColor: COLORS.BOARD_BORDER,
    opacity: 0.5,
  },
  bgLine2: {
    position: 'absolute',
    bottom: '18%',
    left: -20,
    right: -20,
    height: 1,
    backgroundColor: COLORS.BOARD_BORDER,
    opacity: 0.5,
  },
  snakeEmoji: {
    fontSize: 64,
    marginBottom: 12,
  },
  title: {
    fontSize: 72,
    fontWeight: '900',
    color: COLORS.SNAKE_HEAD,
    letterSpacing: 12,
    textAlign: 'center',
    textShadowColor: COLORS.SNAKE_HEAD,
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 20,
    fontFamily: 'monospace',
  },
  titleSub: {
    fontSize: 28,
    fontWeight: '700',
    color: COLORS.TEXT_PRIMARY,
    letterSpacing: 18,
    textAlign: 'center',
    marginTop: -8,
    opacity: 0.7,
    fontFamily: 'monospace',
  },
  tagline: {
    color: COLORS.TEXT_DIM,
    fontSize: 14,
    letterSpacing: 3,
    marginTop: 16,
    marginBottom: 24,
    fontFamily: 'monospace',
  },
  snakeDecor: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 36,
    gap: 6,
  },
  snakeDot: {
    width: 18,
    height: 18,
    borderRadius: 4,
    backgroundColor: COLORS.SNAKE_BODY,
  },
  startBtn: {
    backgroundColor: COLORS.SNAKE_HEAD,
    paddingVertical: 16,
    paddingHorizontal: 48,
    borderRadius: 50,
    alignItems: 'center',
    shadowColor: COLORS.SNAKE_HEAD,
    shadowOpacity: 0.7,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 0 },
    elevation: 10,
    width: '80%',
  },
  startBtnText: {
    color: COLORS.BG,
    fontSize: 18,
    fontWeight: '900',
    letterSpacing: 3,
    fontFamily: 'monospace',
  },
  footer: {
    position: 'absolute',
    bottom: 40,
    color: COLORS.TEXT_DIM,
    fontSize: 12,
    letterSpacing: 2,
    fontFamily: 'monospace',
  },
});

export default SplashScreen;
