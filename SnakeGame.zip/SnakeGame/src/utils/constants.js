// src/utils/constants.js
// ============================================================
// Game constants - tweak these to adjust difficulty and layout
// ============================================================

import { Dimensions } from 'react-native';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');

// Grid cell size in pixels
export const CELL_SIZE = Math.floor(SCREEN_WIDTH / 20);

// Number of columns and rows based on screen size
export const COLS = Math.floor(SCREEN_WIDTH / CELL_SIZE);
export const ROWS = Math.floor((SCREEN_HEIGHT * 0.6) / CELL_SIZE);

// Game board pixel dimensions
export const BOARD_WIDTH = COLS * CELL_SIZE;
export const BOARD_HEIGHT = ROWS * CELL_SIZE;

// Game tick speed in milliseconds (lower = faster)
export const INITIAL_SPEED = 150;
export const SPEED_INCREMENT = 5; // Speed up every N food eaten
export const SPEED_INCREASE_EVERY = 5;
export const MIN_SPEED = 60; // Maximum speed cap

// Scoring
export const SCORE_PER_FOOD = 10;

// Directions
export const DIRECTION = {
  UP: 'UP',
  DOWN: 'DOWN',
  LEFT: 'LEFT',
  RIGHT: 'RIGHT',
};

// Opposite directions (to prevent 180° reversal)
export const OPPOSITE = {
  UP: 'DOWN',
  DOWN: 'UP',
  LEFT: 'RIGHT',
  RIGHT: 'LEFT',
};

// Direction vectors [row delta, col delta]
export const DIRECTION_VECTOR = {
  UP: { row: -1, col: 0 },
  DOWN: { row: 1, col: 0 },
  LEFT: { row: 0, col: -1 },
  RIGHT: { row: 0, col: 1 },
};

// Game states
export const GAME_STATE = {
  SPLASH: 'SPLASH',
  IDLE: 'IDLE',
  RUNNING: 'RUNNING',
  PAUSED: 'PAUSED',
  GAME_OVER: 'GAME_OVER',
};

// AsyncStorage key
export const HIGH_SCORE_KEY = '@snake_high_score';

// Color palette
export const COLORS = {
  BG: '#0A0A0F',
  BOARD_BG: '#0D0D1A',
  BOARD_BORDER: '#1A1A3A',
  GRID_LINE: '#111128',

  SNAKE_HEAD: '#39FF14',      // Neon green head
  SNAKE_BODY: '#00CC00',      // Slightly darker body
  SNAKE_TAIL: '#007700',      // Darkest tail
  SNAKE_OUTLINE: '#00FF00',

  FOOD: '#FF2222',            // Bright red food
  FOOD_GLOW: '#FF6666',
  FOOD_SHINE: '#FF9999',

  TEXT_PRIMARY: '#E0E0FF',
  TEXT_ACCENT: '#39FF14',
  TEXT_DIM: '#555580',

  BTN_PRIMARY: '#1A1A3A',
  BTN_ACCENT: '#39FF14',
  BTN_DANGER: '#FF3333',
  BTN_BORDER: '#333366',

  SCORE_BG: '#0D0D1A',
  OVERLAY_BG: 'rgba(5, 5, 15, 0.92)',
};
