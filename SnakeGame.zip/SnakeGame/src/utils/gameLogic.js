// src/utils/gameLogic.js
// ============================================================
// Pure functions for Snake game mechanics
// ============================================================

import { COLS, ROWS, DIRECTION_VECTOR } from './constants';

/**
 * Generate a random food position that doesn't overlap the snake.
 * @param {Array} snake - Array of {row, col} objects
 * @returns {{row: number, col: number}}
 */
export const generateFood = (snake) => {
  let food;
  do {
    food = {
      row: Math.floor(Math.random() * ROWS),
      col: Math.floor(Math.random() * COLS),
    };
  } while (snake.some((s) => s.row === food.row && s.col === food.col));
  return food;
};

/**
 * Compute the next snake state after one tick.
 * Returns { snake, ate, dead }
 * @param {Array} snake - Current snake segments [{row, col}]
 * @param {string} direction - Current direction key
 * @param {{row: number, col: number}} food - Current food position
 * @returns {{ snake: Array, ate: boolean, dead: boolean }}
 */
export const moveSnake = (snake, direction, food) => {
  const vector = DIRECTION_VECTOR[direction];
  const head = snake[0];

  const newHead = {
    row: head.row + vector.row,
    col: head.col + vector.col,
  };

  // Wall collision check
  if (newHead.row < 0 || newHead.row >= ROWS || newHead.col < 0 || newHead.col >= COLS) {
    return { snake, ate: false, dead: true };
  }

  // Self-collision check (skip last segment since tail will move)
  const bodyWithoutTail = snake.slice(0, snake.length - 1);
  if (bodyWithoutTail.some((s) => s.row === newHead.row && s.col === newHead.col)) {
    return { snake, ate: false, dead: true };
  }

  // Check if food is eaten
  const ate = newHead.row === food.row && newHead.col === food.col;

  // Build new snake: prepend head, drop tail only if not eating
  const newSnake = [newHead, ...snake];
  if (!ate) {
    newSnake.pop();
  }

  return { snake: newSnake, ate, dead: false };
};

/**
 * Create the initial snake (3 segments, centered, moving right).
 * @returns {Array}
 */
export const createInitialSnake = () => {
  const midRow = Math.floor(ROWS / 2);
  const midCol = Math.floor(COLS / 2);
  return [
    { row: midRow, col: midCol },
    { row: midRow, col: midCol - 1 },
    { row: midRow, col: midCol - 2 },
  ];
};
